use v5.36;
use HTML::LinkExtor;

my $file = shift;
my @links;
my $p = HTML::LinkExtor->new(\&check);

$p->parse_file($file);

foreach (@links) {
  print 'Type: ', shift @$_, "\n";

  while (my ($name, $val) = splice(@$_, 0, 2)) {
    print " $name -> $val\n";
  }
}

sub check(@args) {
  push @links, [@args] if $args[0] eq 'a';
}
