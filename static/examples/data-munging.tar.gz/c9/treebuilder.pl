#!/usr/bin/perl

use v5.36;
use HTML::TreeBuilder;

my $h = HTML::TreeBuilder->new;
$h->parse_file(shift);
$h->dump;
print $h->as_HTML;
