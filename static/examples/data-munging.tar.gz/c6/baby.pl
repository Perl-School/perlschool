use v5.36;
use DateTime;
use DateTime::Format::Baby;

my $baby = DateTime::Format::Baby->new('en');
print $baby->format_datetime(DateTime->now);
print "\n";
