open my $filehandle, '>', 'out.txt' or die "Can't open out.txt: $!";
my $old = select $filehandle;

foreach (@data) {
  print;
}

select $old;

my $file = select $filehandle;
$|=1;
select $file;

select((select($filehandle), $| = 1)[0]);
