while (<$filehandle>) {
  chomp; 
  ...
}
