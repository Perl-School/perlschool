# WARNING: This code works, but only on very simple HTML 
use v5.36;

while (<STDIN>) { 
  s/<.*?>//g; 
  print; 
}

