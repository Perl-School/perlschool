# Data Munging with Perl: code examples

These are the example programs and data files from *Data Munging with Perl*,
second edition, by Dave Cross (Perl School, 2026).

The book's page, with this download, is at
<https://perlschool.com/books/data-munging/>. If you find a mistake in the
book or in these examples, you can report it from that page.

## What's here

There is one directory for each chapter that has code, named after the
chapter's number: `c2` holds the examples from Chapter 2, `c6` those from
Chapter 6, and so on. The programs have the names used in the book's listings,
and the data files they read (CSV, XML, JSON, YAML, HTML and so on) are beside
them.

`c7/test.png` and `c7/test.mp3` are tiny synthetic files made for the
examples that read image and audio tags: the MP3 is half a second of silence.

## Running the examples

The examples are written for Perl 5.36 or later, and every one was run on each
Perl from 5.36 to 5.44 while the book was being finished. A handful in
Chapter 11 use features from Perl 5.40 and say so in the text.

Many examples use modules from CPAN that don't come with Perl. Table B.1 in
Appendix B of the book lists the modules to install for each chapter; the
usual way is `cpanm Module::Name`.

Most programs read from standard input or from a file in the same directory,
as the text of the chapter explains. Four need the Internet:

* `c9/get.pl` and `c9/html_parser.pl` fetch a web page (example.com);
* `c10/cities_weather.pl` and `c10/weather_api.pl` call the Open-Meteo weather
  API.

Run the programs from inside their own directory, so that they find their data
files, for example `cd c6; perl csv.pl < cd.txt`.

## Licence

The code examples are free software. You can redistribute them and modify them
under the same terms as Perl itself: either the GNU General Public License,
version 1 or (at your option) any later version, or the Artistic License. The
texts of both are in your Perl's documentation (`perldoc perlgpl` and
`perldoc perlartistic`).

These examples come with no warranty of any kind. The text of the book, and
its diagrams, are not covered by this licence; they are copyright Dave Cross,
all rights reserved.
