use v5.36;
use utf8;
use Encode qw(encode decode FB_CROAK LEAVE_SRC);

binmode STDOUT, ':encoding(UTF-8)';

# Simulate the classic mistake: UTF-8 bytes decoded as Latin-1.
my $mangled = decode('ISO-8859-1', encode('UTF-8', 'Björk'));
print "Mangled: $mangled\n";

# Undo it by reversing the two steps.
my $fixed = decode('UTF-8', encode('ISO-8859-1', $mangled));
print "Fixed:   $fixed\n";

# Fail loudly instead of guessing: try strict UTF-8 first,
# and fall back to Latin-1 only if the bytes aren't valid UTF-8.
foreach my $bytes ("Bj\xC3\xB6rk", "Bj\xF6rk") {
    my $text = eval { decode('UTF-8', $bytes, FB_CROAK | LEAVE_SRC) };

    unless (defined $text) {
        warn "Not valid UTF-8, trying Latin-1\n";
        $text = decode('ISO-8859-1', $bytes);
    }

    print "Decoded: $text\n";
}
