use v5.36;
use utf8;

my @words = ('straße', 'STRASSE');

print "lc: ", (lc($words[0]) eq lc($words[1]) ? 'equal' : 'not equal'), "\n";
print "fc: ", (fc($words[0]) eq fc($words[1]) ? 'equal' : 'not equal'), "\n";
