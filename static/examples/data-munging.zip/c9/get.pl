use LWP::Simple; 

my $page = get('https://example.com/');
getprint('https://example.com/');
getstore('https://example.com/', 'example.html');
