# WARNING: This code doesn't work either
use v5.36;

while (<STDIN>) {
  s/<.*?>//;
  print;
}
