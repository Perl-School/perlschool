# WARNING: This code doesn't work
use v5.36;

while (<STDIN>) {
  s/<.*>//;
  print;
}
