#!/usr/bin/perl

use v5.36;

my ($input, $output) = @ARGV;
open(my $in_fh, '<', $input) or die "Can't open $input for reading: $!";
open(my $out_fh, '>', $output) or die "Can't open $output for writing: $!";

while (<$in_fh>) {
  print $out_fh munge_data($_);
}
