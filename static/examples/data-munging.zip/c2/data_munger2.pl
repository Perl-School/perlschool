#!/usr/bin/perl 

use v5.36;

while (<STDIN>) { 
  print munge_data($_); 
}
