#!/usr/bin/perl 

use v5.36;

while (<>) { 
  print munge_data($_); 
}
