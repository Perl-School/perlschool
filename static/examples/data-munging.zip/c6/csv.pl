use v5.36;
use Text::CSV;

sub read_csv($fh) {
  my $csv = Text::CSV->new({ binary => 1, auto_diag => 1 });

  my @data;

  while (my $row = $csv->getline($fh)) {
    push @data, $row;
  }

  return \@data;
}

sub write_csv($data) {
  my $csv = Text::CSV->new({ binary => 1 });

  foreach (@$data) {
    $csv->combine(@$_);
    print $csv->string;
  }
}

my $data = read_csv(\*STDIN);
foreach (@$data) {
  # Do something to each record.
  # Individual fields are accessed as
  # $_->[0], $_->[1], etc ...
}

write_csv($data);
