use v5.36;
use DateTime;

my $now = DateTime->now;
my $days = ($now->day_of_week + 1) % 7;
print $now->subtract(days => $days);
print "\n";
