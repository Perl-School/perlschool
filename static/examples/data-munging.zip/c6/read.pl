while (<$filehandle>) {
  chomp; 
  ...
}
