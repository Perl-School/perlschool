#!/usr/bin/perl

use v5.36;
use XML::RSS;
use POSIX qw(strftime);

my $rss = XML::RSS->new(version => '2.0');

$rss->channel(
  title => "Dave's News",
  link => 'https://daves.news',
  language => 'en',
  description => "All the news that's unfit to print!",
  pubDate => strftime('%a, %d %b %Y %H:%M:%S %z', localtime),
  managingEditor => 'ed@daves.news',
  webMaster => 'webmaster@daves.news');

$rss->image(title => "Dave's News",
  url => 'https://daves.news/images/logo.png',
  link => 'https://daves.news');

$rss->add_item(title=>'Data Munging Book tops best sellers list',
  link=>'https://daves.news/stories/1');

$rss->add_item(title=>'Smart fridge locks owner out pending software update',
  link=>'https://daves.news/stories/2');

$rss->add_item(title=>'Developer parses HTML with regex, regrets it',
  link=>'https://daves.news/stories/3');

$rss->save('news.rss');
