#!/usr/bin/perl

use v5.36;

(@ARGV == 2) or die "Error: source and target formats not given.";

my ($src, $tgt) = @ARGV;

my %conv = (
  CR   => "\r",
  LF   => "\n",
  CRLF => "\r\n",
);

$src = $conv{$src};
$tgt = $conv{$tgt};

binmode STDIN;
binmode STDOUT;

$/ = $src;

while (<STDIN>) {
  s/$src/$tgt/g;
  print;
}
