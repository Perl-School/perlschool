use Number::Format;

my $eu = Number::Format->new(INT_CURR_SYMBOL => 'EUR ',
                             THOUSANDS_SEP => '.',
                             DECIMAL_POINT => ',');
my $number = 1234567.890;

print $eu->format_number($number), "\n";
print $eu->format_negative($number), "\n";
print $eu->format_price($number), "\n";
