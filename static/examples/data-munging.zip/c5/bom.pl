use v5.36;

open my $in, '<:encoding(UTF-8)', 'excel_export.csv'
    or die "Can't open excel_export.csv: $!";

binmode STDOUT, ':encoding(UTF-8)';

my $header = <$in>;
chomp $header;

printf "Before: [%s] (%d characters)\n", $header, length $header;

$header =~ s/^\x{FEFF}//;

printf "After:  [%s] (%d characters)\n", $header, length $header;

while (my $line = <$in>) {
    chomp $line;
    my ($artist, $country) = split /,/, $line;
    print "$artist is from $country\n";
}
